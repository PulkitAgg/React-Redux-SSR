# React-Redux-SSR
Simple server side rendering in node for react with redux.
