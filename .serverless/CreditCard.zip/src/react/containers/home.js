import { connect } from 'react-redux';
import HomeComponent from '../components/home/homeComponent';

const mapStateToProps = (state) => ({

});

const mapDispatchToProps = (dispatch) => ({

});

const Home = connect(
  mapStateToProps,
  mapDispatchToProps
)(HomeComponent);

export default Home;