// var formidable = require('formidable'),
//     form = new formidable.IncomingForm();

// var fileOp = {
//     parseFiles: function(req, res, next) {
//         form.parse(req, function(err, fields, files) {
//             console.log(files);
//             return next() ;
//         });
//     }
// };

// module.exports = fileOp;