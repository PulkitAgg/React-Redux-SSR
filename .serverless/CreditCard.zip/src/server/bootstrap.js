/**
 * Created by Suraj on 23/01/19.
 * bootstraping files for global use
 */

// global.rootRequire = function (name) {
//     return require(__dirname + "/" + name);
// }

/**
 * __base for getting application base folder
 */

global.__base = __dirname + "/";

/**
 * _config for global config
 */

// global._config = rootRequire('config/config');

/**
 * _log for logging
 */
// global._log = require('debug')('log');

// error codes
//global._resCodes = require('./config/responseCodes');

//helper methods

//global._helpers = require('./app/modules/utils/helpers');
