// var env = process.env.ENV || 'local';
// require('dotenv').config({ path: __base + 'envs/.env.'+env });

// var config = {
//     env: env ,
//     dbUrl: process.env.MONGODB_URL,
//     privStatus: process.env.PRIV_STATUS.split(","),
//     user: process.env.USERS.split(",")
// }; 

// module.exports = config;
