const reqHandler = require('./reqHandler');


module.exports.handler  = (event, context, callback) => {
  reqHandler.createapplication(event, context, callback);
};
