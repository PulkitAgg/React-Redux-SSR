const AWS = require('aws-sdk');
// const util = require('../util');
// const mysqlDbHandler = require('../mysqlDbHandler');
// const mysqlpool = mysqlDbHandler.mysqlpool;


let reqHandler = {

    createapplication: function (event, context, callback) {

        // let response = util.getResObj();
        const body = JSON.parse(event["body"]);
      
        const input = [body["customerid"], body["bankid"], body["statusid"],body["offerid"], body["income"],
                       body["pincode"],body["latlong"], body["macaddress"], body["browser"],body["os"], 
                       body["source"], body["createdby"],body["createdip"],"",""];

        try {
            return callback(null, {"response":"response"});
        }
        catch (ex) {
            console.log("Error " + ex);
        }

    }

};

module.exports = reqHandler;